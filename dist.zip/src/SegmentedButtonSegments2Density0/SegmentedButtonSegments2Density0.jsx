import "./SegmentedButtonSegments2Density0.css";
import { Stars } from "../Stars/Stars.jsx";
import { BuildingBlocksSegmentedButtonButtonSegmentStartConfigurationLabelOnlyStateEnabledSelectedTrue } from "../BuildingBlocksSegmentedButtonButtonSegmentStartConfigurationLabelOnlyStateEnabledSelectedTrue/BuildingBlocksSegmentedButtonButtonSegmentStartConfigurationLabelOnlyStateEnabledSelectedTrue.jsx";
import { BuildingBlocksSegmentedButtonButtonSegmentEndConfigurationLabelOnlyStateEnabledSelectedFalse } from "../BuildingBlocksSegmentedButtonButtonSegmentEndConfigurationLabelOnlyStateEnabledSelectedFalse/BuildingBlocksSegmentedButtonButtonSegmentEndConfigurationLabelOnlyStateEnabledSelectedFalse.jsx";

export const SegmentedButtonSegments2Density0 = ({
  segments = "5",
  density = "3",
  className,
  ...props
}) => {
  const variantsClassName = "segments-" + segments + " density-" + density;

  return (
    <div
      className={
        "segmented-button-segments-2-density-0 " +
        className +
        " " +
        variantsClassName
      }
    >
      <BuildingBlocksSegmentedButtonButtonSegmentStartConfigurationLabelOnlyStateEnabledSelectedTrue
        icon={<Stars className="stars-instance" />}
        configuration="label-only"
        state="enabled"
        selected="true"
        className="segment-start-instance"
      ></BuildingBlocksSegmentedButtonButtonSegmentStartConfigurationLabelOnlyStateEnabledSelectedTrue>
      <BuildingBlocksSegmentedButtonButtonSegmentEndConfigurationLabelOnlyStateEnabledSelectedFalse
        icon={<Stars className="stars-instance" />}
        configuration="label-only"
        state="enabled"
        className="segment-end-instance"
      ></BuildingBlocksSegmentedButtonButtonSegmentEndConfigurationLabelOnlyStateEnabledSelectedFalse>
    </div>
  );
};

import "./Section1.css";
import { SegmentedButtonSegments2Density0 } from "../SegmentedButtonSegments2Density0/SegmentedButtonSegments2Density0.jsx";
import { SelectFieldStateDefaultValueTypeDefault } from "../SelectFieldStateDefaultValueTypeDefault/SelectFieldStateDefaultValueTypeDefault.jsx";
import { XSize16 } from "../XSize16/XSize16.jsx";
import { StarSize16 } from "../StarSize16/StarSize16.jsx";
import { ButtonVariantPrimaryStateDefaultSizeMedium } from "../ButtonVariantPrimaryStateDefaultSizeMedium/ButtonVariantPrimaryStateDefaultSizeMedium.jsx";
import { TabStateDefaultActiveOff } from "../TabStateDefaultActiveOff/TabStateDefaultActiveOff.jsx";

export const Section1 = ({ className, ...props }) => {
  return (
    <div className={"section-1 " + className}>
      <SegmentedButtonSegments2Density0
        segments="2"
        density="0"
        className="segmented-button-instance"
      ></SegmentedButtonSegments2Density0>
      <SelectFieldStateDefaultValueTypeDefault
        label="Тип данных"
        value="Спутниковые"
        className="select-field-instance"
      ></SelectFieldStateDefaultValueTypeDefault>
      <SelectFieldStateDefaultValueTypeDefault
        label="Года"
        value="2024"
        className="select-field-instance2"
      ></SelectFieldStateDefaultValueTypeDefault>
      <SelectFieldStateDefaultValueTypeDefault
        label="Величины"
        value="м/с"
        className="select-field-instance3"
      ></SelectFieldStateDefaultValueTypeDefault>
      <SelectFieldStateDefaultValueTypeDefault
        label="Тип выборки"
        value="Среднедневные"
        className="select-field-instance4"
      ></SelectFieldStateDefaultValueTypeDefault>
      <ButtonVariantPrimaryStateDefaultSizeMedium
        label="Скачать"
        iconEnd={<XSize16 className="x-instance" size="16" />}
        iconStart={<StarSize16 className="star-instance" size="16" />}
        className="button-instance"
      ></ButtonVariantPrimaryStateDefaultSizeMedium>
      <TabStateDefaultActiveOff
        label="Предпросмотр"
        className="tab-instance"
      ></TabStateDefaultActiveOff>
      <img className="image" src="image0.png" />
    </div>
  );
};

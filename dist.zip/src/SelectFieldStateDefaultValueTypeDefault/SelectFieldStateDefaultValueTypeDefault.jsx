import "./SelectFieldStateDefaultValueTypeDefault.css";
import { ChevronDownSize16 } from "../ChevronDownSize16/ChevronDownSize16.jsx";

export const SelectFieldStateDefaultValueTypeDefault = ({
  hasLabel = true,
  hasError = true,
  label = "Label",
  error = "Error",
  open = false,
  description = "Description",
  hasDescription = false,
  value = "Value",
  state = "default",
  valueType = "default",
  className,
  ...props
}) => {
  const variantsClassName = "state-" + state + " value-type-" + valueType;

  return (
    <div
      className={
        "select-field-state-default-value-type-default " +
        className +
        " " +
        variantsClassName
      }
    >
      {hasLabel && (
        <>
          <div className="label">{label} </div>
        </>
      )}
      {hasDescription && (
        <>
          <div className="description">{description} </div>
        </>
      )}
      <div className="select">
        <div className="value">{value} </div>
        <ChevronDownSize16
          size="16"
          className="chevron-down-instance"
        ></ChevronDownSize16>
        {open && (
          <>
            <div className="options">
              <div className="hello-world">Hello World </div>
              <div className="option-2">Option 2 </div>
              <div className="option-3">Option 3 </div>
              <div className="option-4">Option 4 </div>
              <div className="option-5">Option 5 </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

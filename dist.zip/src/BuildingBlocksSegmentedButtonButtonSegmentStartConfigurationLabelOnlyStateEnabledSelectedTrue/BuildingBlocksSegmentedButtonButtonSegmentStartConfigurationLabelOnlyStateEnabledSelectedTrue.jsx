import "./BuildingBlocksSegmentedButtonButtonSegmentStartConfigurationLabelOnlyStateEnabledSelectedTrue.css";
import { Stars } from "../Stars/Stars.jsx";
import { Check } from "../Check/Check.jsx";

export const BuildingBlocksSegmentedButtonButtonSegmentStartConfigurationLabelOnlyStateEnabledSelectedTrue =
  ({
    icon = <Stars className="stars-instance" />,
    labelText = "Label",
    configuration = "icon-only",
    state = "disabled",
    selected = "false",
    className,
    ...props
  }) => {
    const variantsClassName =
      "configuration-" +
      configuration +
      " state-" +
      state +
      " selected-" +
      selected;

    return (
      <div
        className={
          "building-blocks-segmented-button-button-segment-start-configuration-label-only-state-enabled-selected-true " +
          className +
          " " +
          variantsClassName
        }
      >
        <div className="container">
          <div className="state-layer">
            <Check className="selected-icon-instance"></Check>
            <div className="label-text">{labelText} </div>
          </div>
        </div>
      </div>
    );
  };

import "./TabStateDefaultActiveOff.css";

export const TabStateDefaultActiveOff = ({
  label = "Label",
  state = "default",
  active = "off",
  className,
  ...props
}) => {
  const variantsClassName = "state-" + state + " active-" + active;

  return (
    <div
      className={
        "tab-state-default-active-off " + className + " " + variantsClassName
      }
    >
      <div className="label">{label} </div>
    </div>
  );
};

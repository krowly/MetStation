import "./ChevronDownSize16.css";

export const ChevronDownSize16 = ({ size = "48", className, ...props }) => {
  const variantsClassName = "size-" + size;

  return (
    <img
      className={"chevron-down-size-16 " + className + " " + variantsClassName}
      src="chevron-down-size-16.svg"
    />
  );
};

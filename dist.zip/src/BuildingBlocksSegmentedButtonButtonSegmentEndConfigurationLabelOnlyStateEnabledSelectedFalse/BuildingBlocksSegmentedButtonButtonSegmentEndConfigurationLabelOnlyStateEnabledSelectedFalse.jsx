import "./BuildingBlocksSegmentedButtonButtonSegmentEndConfigurationLabelOnlyStateEnabledSelectedFalse.css";
import { Stars } from "../Stars/Stars.jsx";

export const BuildingBlocksSegmentedButtonButtonSegmentEndConfigurationLabelOnlyStateEnabledSelectedFalse =
  ({
    icon = <Stars className="stars-instance" />,
    labelText = "Label",
    configuration = "icon-only",
    state = "disabled",
    selected = "false",
    className,
    ...props
  }) => {
    const variantsClassName =
      "configuration-" +
      configuration +
      " state-" +
      state +
      " selected-" +
      selected;

    return (
      <div
        className={
          "building-blocks-segmented-button-button-segment-end-configuration-label-only-state-enabled-selected-false " +
          className +
          " " +
          variantsClassName
        }
      >
        <div className="container">
          <div className="state-layer">
            <div className="label-text">{labelText} </div>
          </div>
        </div>
      </div>
    );
  };

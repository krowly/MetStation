import "./styles.css";

import { Section1 } from "./Section1/Section1";

export default function App() {
  return (
    <div>
      <Section1 />
    </div>
  );
}

import "./Check.css";

export const Check = ({ className, ...props }) => {
  return <img className={"check " + className} src="check.svg" />;
};
